/*
	This code was written by Nick Darnell
	
	Plugin created by Rama
*/
#include "GamepadUMGPluginPrivatePCH.h"

DEFINE_LOG_CATEGORY(GamepadUMGPlugin)

IMPLEMENT_MODULE(FDefaultGameModuleImpl, GamepadUMGPlugin);