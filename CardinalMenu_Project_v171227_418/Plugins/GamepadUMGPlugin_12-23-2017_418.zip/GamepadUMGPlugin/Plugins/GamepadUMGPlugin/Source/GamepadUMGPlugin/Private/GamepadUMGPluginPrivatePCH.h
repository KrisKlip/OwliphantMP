/*
	This code was written by Nick Darnell
	
	Plugin created by Rama
*/
#pragma once

#include "Engine.h"
#include "GamepadUMGPluginClasses.h"

DECLARE_LOG_CATEGORY_EXTERN(GamepadUMGPlugin, Log, All);
