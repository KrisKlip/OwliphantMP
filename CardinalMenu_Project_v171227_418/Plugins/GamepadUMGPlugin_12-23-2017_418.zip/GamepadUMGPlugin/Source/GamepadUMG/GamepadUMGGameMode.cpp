// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "GamepadUMG.h"
#include "GamepadUMGGameMode.h"
#include "GamepadUMGCharacter.h"

AGamepadUMGGameMode::AGamepadUMGGameMode()
{

}
